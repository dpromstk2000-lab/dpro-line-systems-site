STEP DPRO-WEB-1
DPRO LINE SYSTEMS トップページ基本版

【ファイル】
1. index_step_dpro_web_1.html
2. styles_step_dpro_web_1.css
3. script_step_dpro_web_1.js
4. 各TEXT版

【確認方法】
3ファイルを同じフォルダに置き、index_step_dpro_web_1.htmlをブラウザで開いてください。

【GitHub公開時】
- HTMLを index.html に変更
- CSSを styles.css に変更
- JSを script.js に変更
- HTML内の参照名も同じ名前に変更

今回はSTEP識別を優先し、ファイル名にSTEP番号を入れています。

【次STEP予定】
STEP DPRO-WEB-2：システム一覧専用ページ＋各カードから詳細ページへ移動できる構成
